<?php
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "phbjhqjx_Assign");
define("DB_PASSWORD", "assign@123");
define("DB_DATABASE", "phbjhqjx_AssignmentApp");

/*
 * Google API Key
 */
define("GOOGLE_API_KEY", "AIzaSyBuEKslsuANbJtbxVmCgHIAEDGdbX1rQpE"); // Place your Google API Key
?>